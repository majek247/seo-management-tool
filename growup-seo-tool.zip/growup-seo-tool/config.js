// Supabase > Project Settings > API. The anon key is safe in the browser because RLS protects the data.
window.CFG = {
  url: "https://YOUR-PROJECT.supabase.co",
  key: "YOUR-ANON-KEY"
};
